package fileio; 
import java.io.*; 

public class FileReadWrite {

private File file;				
	private FileWriter writer;		
	private FileWriter writer2;		
	private FileWriter writer3;		
	private FileReader reader;		
	private FileReader reader2;		
	private FileReader reader3;		
	private BufferedReader bfr;		
	private BufferedReader bfr2;		
	private BufferedReader bfr3;		
	
	//REGISTRATION
	public void writeInFile(String s)
	{
		
		try
		{
			file = new File("fileio/RegisterHistory.txt");	
			file.createNewFile();					
			writer = new FileWriter(file, true);
			writer.write(s+"\r"+"\n");				
			writer.flush();							
			writer.close();							
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
	
	public void readFromFile()
	{
		
		try
		{
			reader = new FileReader(file);			
			bfr = new BufferedReader(reader);	
			String text="", temp;					
			
			while((temp=bfr.readLine())!=null)		
			{
				text=text+temp+"\n"+"\r";			
			}
			
			System.out.println(text);			
			reader.close();							
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
	




//INFORMATIONS WORLDWIDE
public void writeWInfoInFile(String a)
	{
		
		try
		{
			file = new File("fileio/WorldInfoHistory.txt");	
			file.createNewFile();					
			writer2 = new FileWriter(file, true);
			writer2.write(a+"\r"+"\n");				
			writer2.flush();							
			writer2.close();							
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
	
	public void readFromWInfoFile()
	{
		
		try
		{
			reader2 = new FileReader(file);			
			bfr2 = new BufferedReader(reader2);	
			String text="", temp;					
			
			while((temp=bfr2.readLine())!=null)		
			{
				text=text+temp+"\n"+"\r";			
			}
			
			System.out.println(text);			
			reader2.close();							
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}



//INFORMATION BANGLADESH
public void writeBInfoInFile(String m)
	{
		
		try
		{
			file = new File("fileio/BangladeshInfoHistory.txt");	
			file.createNewFile();					
			writer3 = new FileWriter(file, true);
			writer3.write(m+"\r"+"\n");				
			writer3.flush();							
			writer3.close();							
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
	
	public void readFromBInfoFile()
	{
		
		try
		{
			reader3 = new FileReader(file);			
			bfr3 = new BufferedReader(reader3);	
			String text="", temp;					
			
			while((temp=bfr3.readLine())!=null)		
			{
				text=text+temp+"\n"+"\r";			
			}
			
			System.out.println(text);			
			reader3.close();							
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}


















}