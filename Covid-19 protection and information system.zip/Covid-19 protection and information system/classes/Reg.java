package classes;
//import interfaces.*;
public class Reg  {
	
	String name,nid,address,num,district,profession;
	int age,wordno;
	

public Reg(){}

public Reg(String name,String nid,String address,String num,String district,String profession,int age,int wordno)
{
	this.name=name;
	this.nid=nid;
	this.address=address;
	this.num=num;
	this.district=district;
	this.profession=profession;
	this.age=age;
	this.wordno=wordno;
	
}

public void setName(String name){	this.name=name;}
public void setNid(String nid){	this.nid=nid;}
public void setAddress(String address){	this.address=address;}
public void setNumber(String num){	this.num=num;}
public void setDistrict(String district){	this.district=district;}
public void setProfession(String profession){	this.profession=profession;}
public void setAge(int age){	this.age=age;}
public void setWord(int wordno){	this.wordno=wordno;}

public String getName(){return name;}
public String getNid(){return nid;}
public String getAddress(){return address;}
public String getNumber(){return num;}
public String getDistrict(){return district;}
public String getProfession(){return profession;}
public int getAge(){return age;}
public int getWord(){return wordno;}

public void ShowInfo(){
	
	System.out.println();
	System.out.println();
	System.out.println("\t\t\t\t Name        : "+name);
	System.out.println("\t\t\t\t Nid         : "+nid);
	System.out.println("\t\t\t\t Address     : "+address);
	System.out.println("\t\t\t\t Number      : "+num);
	System.out.println("\t\t\t\t District    : "+district);
	System.out.println("\t\t\t\t Profession  : "+profession);
	System.out.println("\t\t\t\t Age         : "+age);
	System.out.println("\t\t\t\t Word No.    : "+wordno);
	System.out.println();
	System.out.println();
		
}
	
}