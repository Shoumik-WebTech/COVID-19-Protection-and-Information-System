package classes;
import java.util.*;
public class binfo{
	
	String bcase, bRcover, bdeath;
	
	
public binfo(){}

public binfo(String bcase,String bRcover,String bdeath)
{
	this.bcase=bcase;
	this.bRcover=bRcover;
	this.bdeath=bdeath;
	
}


public void setbTcase(String bcase){this.bcase=bcase;}
public void setbRcover(String bRcover){this.bRcover=bRcover;}
public void setbDeath(String bdeath){this.bdeath=bdeath;}

public String getbTcase(){return bcase;}
public String getbRcover(){return bRcover;}
public String getbDeath(){return bdeath;}


public void bShow(){
		System.out.print(" Bangladesh Cases ");
		System.out.print(" ");
		System.out.println(" ");

	    System.out.println(" Total Cases     : "+bcase);
		System.out.println(" Total Recovered : "+bRcover);
		System.out.println(" Total Deaths    : "+bdeath);

		
	}
	

	
	
}