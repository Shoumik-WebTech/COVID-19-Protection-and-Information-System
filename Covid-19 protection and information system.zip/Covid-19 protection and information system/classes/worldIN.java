package classes;
import java.util.*;
public class worldIN{
	
	String Tcase, Rcover, death;
	
	
public worldIN(){}

public worldIN(String Tcase,String Rcover,String death)
{
	this.Tcase=Tcase;
	this.Rcover=Rcover;
	this.death=death;
	
}


public void setTcase(String Tcase){this.Tcase=Tcase;}
public void setRcover(String Rcover){this.Rcover=Rcover;}
public void setDeath(String death){this.death=death;}

public String getTcase(){return Tcase;}
public String getRcover(){return Rcover;}
public String getDeath(){return death;}


public void wShow(){
		System.out.print(" World wide Cases ");
		System.out.print(" ");
		System.out.println(" ");

	    System.out.println(" Total Cases     : "+Tcase);
		System.out.println(" Total Recovered : "+Rcover);
		System.out.println(" Total Deaths    : "+death);

		
	}
	

	
	
}