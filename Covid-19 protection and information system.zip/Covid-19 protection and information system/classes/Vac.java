package classes;
public class Vac{
	
	public void VAC1(){
		
		System.out.println("While vaccine supplies are limited, it is recommended that priority be given to health workers at high risk of exposure and older people, including those aged 65 or older. ");
		System.out.println("Based on data provided by the manufacturer, the Astrazeneca-Oxford vaccine, or AZD1222, has shown to be 63% effective in an ongoing, large-scale clinical trial ");
	}
	
	
	
	public void VAC2(){
		
		System.out.println("A Recently Concluded Large-Scale Trial Found Pfizer's Vaccine Is More Than 90% Effective.Pfizer Announced That Its COVID-19 Vaccine Has Been Found To Be More Than 90%Effective.  ");
		System.out.println(" WHO does not recommend vaccination of children below 16 years of age, even if they belong to a high-risk group. ");
	}
	
	
	
}