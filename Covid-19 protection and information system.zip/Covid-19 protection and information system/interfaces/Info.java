package interfaces;
interface Info{
	void ShowInfo();
}