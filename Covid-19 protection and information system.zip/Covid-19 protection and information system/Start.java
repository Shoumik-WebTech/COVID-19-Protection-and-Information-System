import java.lang.*;
import classes.*;
import fileio.*;
//import interfaces.*;
import java.util.*;

public class Start
{
	public static void cls() {
		try {
			new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
		} catch(Exception E) {
			System.out.println(E);
		}
	}
	
	
	
	
	
	
	
	
	public static void main(String args[])
	{

		int i;
		String password;
		String pass="Admin";
		boolean choice = true;
		boolean Login = true;
		Scanner sc = new Scanner(System.in);
		Scanner sc1 = new Scanner(System.in); 
		Scanner sc2 = new Scanner(System.in); 
		Scanner sc3 = new Scanner(System.in); 
		Scanner sc4 = new Scanner(System.in); 
		Scanner sc5 = new Scanner(System.in); 
		Scanner sc6 = new Scanner(System.in); 
		Scanner sc7 = new Scanner(System.in); 
		Scanner sc8 = new Scanner(System.in); 
		Scanner a1= new Scanner(System.in);
		
		Reg obj1=new Reg();
		worldIN obj3=new worldIN();
		binfo obj4=new binfo();
		Vac obj5=new Vac();
        FileReadWrite save=new FileReadWrite();
        FileReadWrite save2=new FileReadWrite();
		

		System.out.println(" ");
		System.out.println("                ~Welcome~  ");
		System.out.println(" ");
		System.out.println(" Covid-19 Protection & Information System.");
		while(choice)
		{	
	Login=true;
	

			System.out.println("             Menu ");
			System.out.println("	1. Covid-19 Information.");
			System.out.println("	2. Covid-19 Vaccine Information.");
			System.out.println("	3. Covid-19 Vaccine Registration.");
			System.out.println("	4. About.");
			System.out.println("	5. Administration.");
			System.out.println("	6. Exit.");
			System.out.print("    What do you want to do? : ");
			
			int first = sc.nextInt();
			
			switch(first)
			{
				case 1:
					
					System.out.println("");
					System.out.println("    Covid-19 Information  ");
					System.out.println("    ==================== ");
					System.out.println("");
					System.out.println("	1. World Wide Information.");
					System.out.println("	2. Bangladesh Information.");
					System.out.println("	3. Go Back\n");
					System.out.print("Choose Your Option : ");
					int second1 = sc.nextInt();
					
					switch(second1)
					{
						case 1:
						//METHOD FOR INFORMATION(WORLD WIDE)
						save.readFromWInfoFile();
							break;
							
						case 2:
						//METHOD FOR INFORMATION(BANGLADESH)
						save2.readFromBInfoFile();
					
							
							break;
							
						case 3:
						
							System.out.println("You have Selected to Go Back");
							break;
						
						default:
							
							System.out.println("Invalid Input");
							break;
					}
					
					break;
					
				case 2:
				
				
					System.out.println("Covid-19 Vaccine Information.");
					System.out.println("=============================");
					
					System.out.println("           Options");
					System.out.println("	1. Vaccine 1.");
					System.out.println("	2. Vaccine 2.");
					System.out.println("	3. Go Back");
					System.out.print("What do you want to do? : ");
					int second2 = sc.nextInt();
					
					switch(second2)
					{
						case 1:
						
						
							System.out.println(" VACCINE 1 INFORMATION. ");
							System.out.println("======================== ");
							obj5.VAC1();
							break;
							
						case 2:
						
							System.out.println(" VACCINE 2 INFORMATION. ");
							System.out.println("========================");
							obj5.VAC2();
							break;
						
						case 3:
							System.out.println(". . .Going Back . . .");
							break;
							
						default:
						
							System.out.println("Invalid Input");
							break;
					}
					
					break;
				
				case 3:
					
					System.out.println(" Covid-19 Vaccine Registration. ");
					System.out.println("================================");
					
					System.out.println("              OPTIONS");
					System.out.println("	1. Register.");
					System.out.println("	2. Show Registered Information.");
					System.out.println("	3. Go Back.");
					System.out.print("Choose Your Option: ");
					int second3 = sc.nextInt();
					
					switch(second3)
					{
						case 1: 
													
							System.out.println(" REGISTER. ");
							System.out.println("===========");
						
						
						System.out.println();
						System.out.println();
						System.out.println();
						
						System.out.println(" Registration Form ");
						System.out.println();
						System.out.print(" Enter Your Name        : ");
						String name= sc1.nextLine(); 
						
						System.out.print(" Enter Your Nid         : ");
						String nid=sc2.nextLine();
						
						System.out.print(" Enter Your Address     : ");
						String address=sc3.nextLine();
						
						System.out.print(" Enter Your Number      : ");
						String num=sc4.nextLine();
						
						System.out.print(" Enter Your District    : ");
						String district=sc5.nextLine();
						
						System.out.print(" Enter Your Proffession : ");
						String proffession=sc6.nextLine();
						
						System.out.print(" Enter Your Age(Must be 18+) : ");
						int age=sc7.nextInt();
						
						System.out.print(" Enter Your Word No.    : ");
						int wordno=sc8.nextInt();
						
						
						obj1.setName(name);
						obj1.setNid(nid);
						obj1.setAddress(address);
						obj1.setNumber(num);
						obj1.setDistrict(district);
						obj1.setProfession(proffession);
						obj1.setAge(age);
						obj1.setWord(wordno);
						
						save.writeInFile("Your Name: "+obj1.getName());
						save.writeInFile("Your NID : "+obj1.getNid());
						save.writeInFile("Your Adress: "+obj1.getAddress());
						save.writeInFile("Your Phone Number: "+obj1.getNumber());
						save.writeInFile("Your District "+obj1.getDistrict());
						save.writeInFile("Your Profession: "+obj1.getProfession());
						save.writeInFile("Your age: "+obj1.getAge());
						save.writeInFile("Word Number: "+obj1.getWord());
						
						
						
						
							System.out.println("");
							System.out.println(" You have COmpleted Your Registration.!");
							System.out.println("  ");
							System.out.println("  ");
							System.out.println(" You will be informed via messege for further instructions. ");

						
						
						break;
						case 2:
						//obj1.ShowInfo();
							System.out.println(" SHOW REGISTERED INFORMAITION ");
							System.out.println("   ");
						obj1.ShowInfo();	
							
							break;
							
						case 3:		
							System.out.println(". . .Going Back . . .");
							break;
							
						default:
						
							System.out.println("Invalid Input");
							break;
					}
					
					break;
					
				case 4:
				
				System.out.println(" ABOUT.");
				System.out.println("========");
				System.out.println(" The main objective of this code was to make a simple information and registration system. ");
	            System.out.println(" Users can register for vaccine and also see necessary information regarding covid-19 ");
				System.out.println(" Admin Can modify the informations as needed.  ");
							System.out.print(" ");
							System.out.print(" ");
		

					
					break;
					
				case 5:
				while(Login){
					
					cls();
					Login=false;
				System.out.print(" Type User Id  : ");
				i=a1.nextInt();
				
				System.out.print(" Type Password : ");
				Scanner a2= new Scanner(System.in);
				password=a2.nextLine();
				
				
				if(i==123 && password.equals(pass)){
					
					System.out.println(" Login Successfull ");
					System.out.println("   ");
					System.out.println(" [1]Update Info.  ");
					System.out.println(" [2]Show Info ");
					
					System.out.print(" Choose Your Option: ");
					Scanner q=new Scanner(System.in);
					int l=q.nextInt();
					switch(l){
						case 1:
						
						System.out.println(" Update Informations ");
						System.out.println(" ");
     	System.out.print(" World wide Cases ");
		System.out.print(" ");
		System.out.println(" ");
		
		
		System.out.print(" Update Cases     : ");
		Scanner x=new Scanner(System.in);
		String  Tcase=x.nextLine();
		
		System.out.print(" Update Recovered : ");
		Scanner y=new Scanner(System.in);
		String Rcover=y.nextLine();
		
		System.out.print(" Update Deaths    : ");
		Scanner z=new Scanner(System.in);
		String  death=z.nextLine();
		 
		 
		obj3.setTcase(Tcase); 
		obj3.setRcover(Rcover); 
		obj3.setDeath(death); 

		save.writeWInfoInFile(" world wide total case  : "+obj3.getTcase()); 
		save.writeWInfoInFile(" world wide Rocver case : "+obj3.getRcover()); 
		save.writeWInfoInFile(" world Wide Deaths      : "+obj3.getDeath()); 
						
						
						
						
						
		System.out.print(" ");
		System.out.print(" ");
		System.out.println(" ");

						
        System.out.print(" Bangladesh Cases ");
		System.out.print(" ");
		System.out.println(" ");
		
		
		System.out.print(" Update Cases     : ");
		Scanner x1=new Scanner(System.in);
		String  bcase=x1.nextLine();
		
		System.out.print(" Update Recovered : ");
		Scanner y1=new Scanner(System.in);
		String bRcover=y1.nextLine();
		
		System.out.print(" Update Deaths    : ");
		Scanner z1=new Scanner(System.in);
		String  bdeath=z1.nextLine();
		 
		 
		obj4.setbTcase(bcase); 
		obj4.setbRcover(bRcover); 
		obj4.setbDeath(bdeath); 

		save2.writeBInfoInFile(" Bangladesh total case  : "+obj4.getbTcase()); 
		save2.writeBInfoInFile(" Bangladesh Rocver case : "+obj4.getbRcover()); 
		save2.writeBInfoInFile(" Bangladesh Deaths      : "+obj4.getbDeath()); 
												
								
						break;
						
						case 2:
						
						System.out.println("  Show Informations ");
						System.out.println("  ");
						obj3.wShow();
						break;
					}
				
				}
				
				else if(i!=123) {
					
					System.out.println(" Invalid User Id ");
					System.out.println(" ");
					System.out.println(" Please try Again.");
				
				}
				
				else if (!password.equals(pass)){
					
				    System.out.println(" Invalid User Password ");
					System.out.println(" ");
					System.out.println(" Please try Again.");	
					
				}
				
				}
					break;
					
				case 6:	
					System.out.println(" ");
					System.out.println(" ");
					System.out.println(" ");
				
				
                    System.out.println("You have selected to exit the application");
					System.out.println("Thank you for using Covid-19 P. & I.");
					System.out.println("--Stay Home =======  Stay Safe.--");
					choice = false;
					break;					
				default:
				
					System.out.println("Invalid Input");
					break;
			}
		}
		
	}
}
